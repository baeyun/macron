// macron.Menubar API

let Menubar = function (menu) {
  return menu
}

module.exports = Menubar
